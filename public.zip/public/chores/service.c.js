/**
 * ServiceWorker
 *
 * @param {*} to improve the user experience, you can also add a Service Worker. Service Workers help the application to function even when the user is offline. You can register a Service Worker
 * @param {in => navigator} navigator APIs for precache in the chrome
 *
 * @license MIT <https://opensource.org/licenses/MIT>
 * @public
 */
'use strict'; if ('serviceWorker' in navigator) {
  navigator.serviceWorker
    .register('./chores/env/service.worker.reapl.js')
    .then(function(registration) {
      console.log(
        '(SUCCESS),  Registered Service Workers with coverage: ',
        registration.scope
      );
    })
    .catch(function(error) {
      console.error(
        '(FATAL),  Service Worker registration failed: ',
        error.stack
      );
    });
}
