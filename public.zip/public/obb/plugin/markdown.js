'use strict'; const markDown = (text) => {
  var inPrint = text;
  const moveBy = [
    { string: /\`\`\`(.*?)\`\`\`/gis, value: '<pre class="language-js line-numbers"><code class="language-js">$1</code></pre>' },
    { string: /`(.*?)`/gis, value: '<code class="ace_a">$1</code>' },
    { string: /\*\*(.*?)\*\*/gis, value: '<b>$1</b>' },
    { string: /~(.*?)~/gis, value: '<s>$1</s>' },
    { string: /\b((?:https?|ftp):\/\/[^\s\°]+)/g, value: '<a href="$1">$1</a>' },
    /** { string: /_(.*?)_/gis, value: '<i>$1<i>' }, */
    /** { string: new RegExp(data.join("|"), "gi"), value: '****' } */
  ];

  moveBy.forEach((moveByOf) => {
    inPrint = inPrint.replace(moveByOf["string"], moveByOf["value"]);
  });

  // Apply highlighting block by block after DOM update
  setTimeout(() => {
    document.querySelectorAll('pre code').forEach((block, index) => {
      setTimeout(() => {
        Prism.highlightElement(block);
      }, index * 100); // Delay each block by 100ms
    });
  }, 0);

  return inPrint.trim(); // Starting text sorting
};
