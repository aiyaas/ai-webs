// Displaying the date
'use strict'; document.querySelector(
    '#useDate'
).textContent = `${new Date().getDate()} ${new Date().toLocaleDateString(
    'id-ID',
    { month: 'short' }
)} ${new Date().getFullYear()}`;

const updateBotStatus = () => {
    const element = document.querySelector('#isActive');
    const hour = new Date().getHours();
    element.textContent = (hour >= 4 && hour < 22) ? 'Online' : 'Evening';
    element.style.color = (hour >= 4 && hour < 22) ? '#2cb590' : '#5597ff';
    // Set time to update current status
    setTimeout(updateBotStatus, 6000);
}

// Update on the status 
updateBotStatus();