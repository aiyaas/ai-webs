"use strict"; function exportCsvModel() {
  let data = JSON.parse(localStorage.getItem("DB"));
  const formatToCSV = (data) => {
    /** convert some 'JSON' to 'CSV' type. */ if (typeof data === "object") {
      return Object.entries(data)
        .map(([key, value]) =>
          typeof value === "object"
            ? `${key}, ${formatToCSV(value)}`
            : `${key}, ${value}`
        )
        .join("\n");
    }
    return null;
  };
  
  try {
      var __createElmtCsv = document.createElement("a");
      __createElmtCsv.setAttribute(
         "href",
         "data:text/csv;charset=utf8," + encodeURIComponent(formatToCSV(data))
      );
      __createElmtCsv.setAttribute("download", `${btoa(new Date())}.spreadsheets.csv`);
      document.body.appendChild(__createElmtCsv);
      __createElmtCsv.click();

      // remove items createElement in the download file
      document.body.removeChild(__createElmtCsv);
  } catch (error) {
      alert("Your browser does not support this feature. Please use a different browser.");
  }
}

