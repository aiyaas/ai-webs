const items = document.querySelectorAll("#listItems");
const searchInput = document.querySelector("#inlineFormInputGroup");
const notFound = document.querySelector("#notFound");

function searchItem(query) {
  items.forEach((item) => {
    const itemText = item.textContent.toLowerCase();
    if (itemText.includes(query.toLowerCase())) {
      item.style.display = "block";
      notFound.style.display = "none";
    } else {
      item.style.display = "none";
      notFound.style.display = "block";
      notFound.innerHTML = "Search results not found!";
    }
  });
}

searchInput.addEventListener("input", () => {
  const query = searchInput.value.trim();
  searchItem(query);
});
