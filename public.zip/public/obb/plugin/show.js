const bodyCard = document.querySelector("#cardst")

function getCard(){ bodyCard.style.display = "block" }
function exist(){ bodyCard.style.display = "none" }
bodyCard.addEventListener("click", function(event){
    if (event.target === this) exist()
})

